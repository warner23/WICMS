<?php
/*
Plugin Name: Facebook like widget
Plugin URI: #
Description: Facebook like widget
Author: Shaon
Version: pro_only
Author URI: #
*/

