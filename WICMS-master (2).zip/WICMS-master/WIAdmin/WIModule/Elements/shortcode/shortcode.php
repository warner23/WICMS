<?php
/*
Plugin Name: ShortCode
Plugin URI: #
Description: Execute Any Short-code
Author: Shaon
Version: pro_only
Author URI: #
*/  
