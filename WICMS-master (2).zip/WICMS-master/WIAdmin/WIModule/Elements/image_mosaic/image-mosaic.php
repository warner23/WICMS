<?php
/*
Plugin Name: Image (mosaic effect)
Plugin URI: #
Description: 10+ Image (mosaic effect)
Author: Shaon
Version: pro_only
Author URI: #
*/

