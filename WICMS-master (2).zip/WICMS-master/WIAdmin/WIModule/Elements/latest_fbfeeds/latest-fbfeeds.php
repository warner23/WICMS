<?php
/*
Plugin Name: Latest facebook feed 
Plugin URI: #
Description: Latest facebook feed 
Author: Shaon
Version: pro_only
Author URI: #
*/

