<?php
/*
Plugin Name:  Subscription form 
Plugin URI: #
Description: Newsletter/Feed Subscription form code embeder
Author: Shaon
Version: pro_only
Author URI: #
*/  
