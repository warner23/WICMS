<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style>
#cpBtn>div
{
 width:20px;
 height:4px;
 background:#333;
 margin:3px 0px;
 border-radius:4px;
}
</style>
</head>

<body>
<button id="cpBtn">
<div></div>
<div></div>
<div></div>
</button>
</body>
</html>