<?php
/*
Plugin Name: List
Plugin URI: #
Description: Render list with different icons
Author: Shaon
Version: pro_only
Author URI: #
*/ 
