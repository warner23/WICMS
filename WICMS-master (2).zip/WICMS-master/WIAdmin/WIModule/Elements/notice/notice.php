<?php
/*
Plugin Name: Notice module
Plugin URI: #
Description: Add notice or alter in layout area
Author: Shaon
Version: pro_only
Author URI: #
*/ 
