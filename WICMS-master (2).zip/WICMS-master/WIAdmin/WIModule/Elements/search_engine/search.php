<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body><center>
<h2>Search Engine</h2>
<form action='./search.php' method='get'/>
<input type='text' name='k' size='100'<?php echo $_GET['k']; ?>/>
<input type"submit" value="search"/>
</form>
</center>

</body>
</html>