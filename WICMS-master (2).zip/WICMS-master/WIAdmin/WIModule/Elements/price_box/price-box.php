<?php
/*
Plugin Name: Price Box
Plugin URI: #
Description: Create a Price Box within seconds
Author: Shaon
Version: pro_only
Author URI: #
*/ 
