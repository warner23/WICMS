<?php

/**
* 
*/
class feature 
{
	
	function __construct()
	{
		
	}

	public function mod_name()
	{
		echo '
		<link rel="stylesheet" type="text/css" href="WIModule/appearing_button/appearing_button.css">
		<div id="box1>
			<a href="#">Change profile Photo</a>
			<img src="#" alt="pic">';
	}
}



