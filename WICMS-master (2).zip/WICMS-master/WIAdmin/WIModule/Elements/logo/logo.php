<?php
/*
Plugin Name: Site logo module
Plugin URI: #
Description: Add site logo in layout area
Author: Shaon
Version: pro_only
Author URI: #
*/ 
