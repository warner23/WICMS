
<link href="css/boilerplate.css" rel="stylesheet" type="text/css">
<link href="css/responce.css" rel="stylesheet" type="text/css">
<link href="css/fluid.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.template.css" media="screen">
<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/style.css" media="screen">
	<link rel="stylesheet" type="text/css" href="css/style.css" media="screen" data-name="skins">
	<link rel="stylesheet" type="text/css" href="css/layout/wide.css" media="screen" data-name="layout"> 
	<link rel="stylesheet" type="text/css" href="css/switcher.css" media="screen" />
<link rel=”icon” href="img/BBT_fav.jpg" type=”image/x-icon”>
<link rel=”shortcut icon” href="img/BBT_fav.jpg" type=”image/x-icon”>