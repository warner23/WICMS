
<body>
<header class="header">
			<!-- Static navbar -->
			<div class="hed">
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-12">
							<div class="navbar_brand"></div>
						</div>
						<div class="col-lg-9 col-md-9 col-sm-12">
							<div id="nav">
		                        <ul id="mainMenu" class="mainMenu default">
		                            <li class="active"><a href="#">Home</a>
		                                <ul class="dropdown">
		                                    <li><a href="index.html">Home Style 1</a></li>
		                                    <li><a href="index_2.html">Home Style 2</a></li>
		                                    <li><a href="index_3.html">Home Style 3</a></li>
		                                    <li><a href="index_4.html">Home Style 4</a></li>
		                                    <li><a href="index_5.html">Home Style 5</a></li>
		                                </ul>
		                            </li>
		                            <li><a href="#">Pages</a>
		                                <ul class="dropdown">
		                                    <li><a href="about.html">About Us</a>
		                                    	<ul class="dropdown">
		                                    		<li><a href="about.html">About 1 </a></li>
		                                    		<li><a href="about_2.html">About 2</a></li>
		                                    	</ul>
		                                    </li>
		                                    <li><a href="services.html">Services</a>
		                                    	<ul class="dropdown">
		                                    		<li><a href="services.html">Services 1 </a></li>
		                                    		<li><a href="services_2.html">Services 2</a></li>
		                                    	</ul>
		                                    </li>
		                                    <li><a href="faq.html">FAQ Page</a></li>
		                                    <li><a href="left_sidebar.html">Left Sidebar</a></li>
		                                    <li><a href="right_sidebar.html">Right Sidebar</a></li>
		                                    <li><a href="fullwidth.html">Full Width</a></li>
		                                    <li><a href="#">Contacts</a>
				                                <ul class="dropdown">
				                                    <li><a href="contact.html">Contact Style 1</a></li>
				                                    <li><a href="contact_2.html">Contact Style 2</a></li>
				                                    <li><a href="contact_3.html">Contact Style 3</a></li>
				                                </ul>
				                            </li>
		                                </ul>
		                            </li>
		                            <li><a href="#">Mega Menu</a>
		                                <div class="megamenu full-width">
		                                    <div class="row">
		                                        <div class="columns_2">
			                                        <div class="title_wmm">
														<h3>Recent Tweets</h3>
													</div>
													<div class="tweet_menu"></div>
		                                        </div>
		                                        <div class="columns_2">
		                                        	<div class="title_wmm">
														<h3>Recent Posts</h3>
													</div>
		                                            <div class="tpl2">
		                                                <ul class="popular_posts_list">
															<li>
																<span>
																	<a href="#" class="post-img">
												                    	<img src="img/blog/recent_3.jpg" alt="">
											                  			<span class="overlay"></span>
											                  		</a>
																</span>
																<p class="wrap">
											                    	<a href="#" class="rp_title">Lorem ipsum dolor consectetur</a>
											                    	<small class="rp_date">January 19, 2014</small>
											                  	</p>
															</li>
															<li>
																<span>
																	<a href="#" class="post-img">
												                    	<img src="img/blog/recent_4.jpg" alt="">
											                  			<span class="overlay"></span>
											                  		</a>
																</span>
																<p class="wrap">
																	<a href="#" class="rp_title">Mublishing packag esanse web page editos</a>
																 	<small class="rp_date">January 19, 2014</small>
															 	</p>
															</li>
														</ul>
		                                            </div><!-- he wrap -->
		                                        </div>
		                                        <div class="columns_2">
			                                        <div class="title_wmm">
														<h3>Flickr Gallery</h3>
													</div>
													<div class="flickr">
														<ul id="flickr" class="flickr_menu"></ul>
													</div>
		                                        </div>
		                                    </div>
		                                </div>
		                            </li>
		                            <li><a href="#">Dropdown</a>
		                                <ul class="dropdown">
		                                    <li><a href="about.html">Menu 1</a></li>
		                                    <li><a href="about.html">Menu 2</a></li>
		                                    <li><a href="about.html">Menu 3</a></li>
		                                    <li><a href="about.html">Menu 4</a>
		                                    	<ul class="dropdown">
		                                    		<li><a href="about.html">Sub Menu 1 </a></li>
		                                    		<li><a href="about.html">Sub Menu  2</a></li>
		                                    		<li><a href="about.html">Sub Menu 3 </a>
		                                    			<ul class="dropdown">
				                                    		<li><a href="about.html">Subsub Menu 1 </a></li>
				                                    		<li><a href="about.html">Subsub Menu 2</a></li>
				                                    		<li><a href="about.html">Subsub Menu 3 </a></li>
				                                    		<li><a href="about.html">Subsub Menu 4</a></li>
				                                    	</ul>
		                                    		</li>
		                                    		<li><a href="about.html">Sub Menu 4</a></li>
		                                    	</ul>
		                                    </li>
		                                    <li><a href="about.html">Menu 5</a></li>
		                                </ul>
		                            </li>
		                            <li><a href="#">Portfolio</a>
		                                <ul class="dropdown">
		                                    <li><a href="portfolio_2.html">Portfolio (2 Columns)</a></li>
		                                    <li><a href="portfolio_3.html">Portfolio (3 Columns)</a></li>
		                                    <li><a href="portfolio_4.html">Portfolio (4 Columns)</a></li>
		                                    <li><a href="portfolio_single.html">Single Portfolio 1</a></li>
		                                    <li><a href="portfolio_single_2.html">Single Portfolio 2</a></li>
		                                </ul>
		                            </li>
		                            <li><a href="#">Blog</a>
		                                <ul class="dropdown">
                                    		<li><a href="blog_style_1.html">Blog Style 1</a></li>
		                                    <li><a href="blog_style_2.html">Blog Style 2</a></li>
		                                    <li><a href="blog_style_3.html">Blog Style 3</a></li>
		                                    <li><a href="blog_style_4.html">Blog Style 4</a></li>
		                                    <li><a href="blog_style_5.html">Blog Style 5</a></li>
		                                    <li><a href="blog_style_6.html">Blog Style 6</a></li>
		                                    <li><a href="blog_masonry.html">Blog Masonry</a>
		                                    	<ul class="dropdown">
				                                    <li><a href="blog_masonry.html">Blog Masonry</a></li>
				                                    <li><a href="blog_masonry_left.html">Blog Masonry Left</a></li>
				                                    <li><a href="blog_masonry_right.html">Blog Masonry Right</a></li>
				                                </ul>
		                                    </li>
		                                    <li><a href="blog-full-width.html">Blog Single</a>
		                                    	<ul class="dropdown">
				                                    <li><a href="blog_post.html">Blog Single 1</a></li>
				                                    <li><a href="blog_post_2.html">Blog Single 2</a></li>
				                                    <li><a href="blog_post_3.html">Blog Single 3</a></li>
				                                </ul>
		                                    </li>
		                                </ul>
		                            </li>
		                            <li><a href="#">Features</a>
		                                <ul class="dropdown">
		                                    <li><a href="elements.html">Elements</a></li>
		                                    <li><a href="columns.html">Grid Systems</a></li>
		                                    <li><a href="pricing.html">Pricing Tables</a></li>
		                                    <li><a href="icons.html">Retina Icons</a></li>
		                                    <li><a href="typography.html">Typography</a></li>
		                                </ul>
		                            </li>
		                        </ul>
		                    </div><!-- nav -->   
						</div>
					</div>
				</div>
			</div>
		</header>
		<!-- End Header --><header class="header">
			
</body>
</html>