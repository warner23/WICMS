

<body>
<!--Start Feature Testimonials-->
		<section class="content feature_parallax" id="parallax">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12" data-effect="slide-top">
						<ul class="bxslider ">
							<li>
								<blockquote>
									Aliquam a orci quis nisi sagittis sagittis. Etiam adipiscing, justo quis feugiat.Suspendisse eu erat quam. Vivamus porttitor eros quis nisi lacinia sed interdum lorem vulputate. Aliquam a orci quis nisi sagittis sagittis. Etiam adipiscing, justo quis feugiat
								</blockquote>
								<div class="tesimonial-autor">
									<h4>John Doe, <a href="#">Creative</a></h4>
								</div>
							</li>
							<li>
								<blockquote>
									Aliquam a orci quis nisi sagittis sagittis. Etiam adipiscing, justo quis feugiat.Suspendisse eu erat quam. Vivamus porttitor eros quis nisi lacinia sed interdum lorem vulputate. Aliquam a orci quis nisi sagittis sagittis. Etiam adipiscing, justo quis feugiat
								</blockquote>
								<div class="tesimonial-autor">
									<h4>John Doe, <a href="#">Creative</a></h4>
								</div>
							</li>
							<li>
								<blockquote>
									Aliquam a orci quis nisi sagittis sagittis. Etiam adipiscing, justo quis feugiat.Suspendisse eu erat quam. Vivamus porttitor eros quis nisi lacinia sed interdum lorem vulputate. Aliquam a orci quis nisi sagittis sagittis. Etiam adipiscing, justo quis feugiat
								</blockquote>
								
								<div class="tesimonial-autor">
									<h4>John Doe, <a href="#">Creative</a></h4>
								</div>
							</li>
							<li>
								<blockquote>
									Aliquam a orci quis nisi sagittis sagittis. Etiam adipiscing, justo quis feugiat.Suspendisse eu erat quam. Vivamus porttitor eros quis nisi lacinia sed interdum lorem vulputate. Aliquam a orci quis nisi sagittis sagittis. Etiam adipiscing, justo quis feugiat
								</blockquote>
								<div class="tesimonial-autor">
									<h4>John Doe, <a href="#">Creative</a></h4>
								</div>
							</li>
						</ul>
						<div id="box-img_testimonial">
							<a data-slide-index="0" href="#"><img alt="" src="img/testimonials/testim-autor.png"/></a>
							<a data-slide-index="1" href="#"><img alt="" src="img/testimonials/testim-autor2.png"/></a>
							<a data-slide-index="2" href="#"><img alt="" src="img/testimonials/testim-autor3.png"/></a>
							<a data-slide-index="3" href="#"><img alt="" src="img/testimonials/testim-autor1.png"/></a>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--End Feature Testimonials-->
</body>
</html>