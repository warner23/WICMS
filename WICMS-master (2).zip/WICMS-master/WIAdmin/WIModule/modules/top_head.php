<div class="t_container">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 col-sm-jm col-lg-sm1">
						<ul class="top_contact">
							<li class="t_phone">
								<p><?php echo $trans['phone']; ?></p>
							</li>
							<li class="t_mail">
								<p><?php echo $trans['email']; ?></p>
							</li>
						</ul>
					</div><!--end col-lg-6 col-md-6 col-sm-6-->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-sm-cl col-lg-sm1 col-lg-tr">
                    <div class="show">
                    <?php include_once 'temp_lang_list.php';?>
                    </div><!-- end show-->
                    </div><!--end col-lg-6 col-md-6 col-sm-6-->
					<div class="col-lg-6 col-md-6 col-sm-6 col-sm-jw col-lg-sm2">
						<div id="sb-search" class="sb-search">
							<form>
								<input class="sb-search-input" placeholder="Enter your search term..." type="text" value="" name="search" id="search">
								<input class="sb-search-submit" type="submit" value="">
								<span class="sb-icon-search"></span>
							</form>
						</div><!-- end search-->
						<ul class="social_media"> 
	                        <li><a href="https://www.facebook.com/groups/598321660275913/" data-placement="bottom" data-toggle="tooltip" class="fa fa-facebook" title="Facebook"><?php echo $trans['socialf']; ?></a></li>
	                        <li><a href="#" data-placement="bottom" data-toggle="tooltip" class="fa fa-google-plus" title="Google+"><?php echo $trans['socialg']; ?></a></li>
	                        <li><a href="#" data-placement="bottom" data-toggle="tooltip" class="fa fa-twitter" title="Twitter"><?php echo $trans['socialt']; ?></a></li>
	                        <li><a href="#" data-placement="bottom" data-toggle="tooltip" class="fa fa-pinterest" title="Pinterest"><?php echo $trans['socialp']; ?></a></li>
	                        <li><a href="#" data-placement="bottom" data-toggle="tooltip" class="fa fa-linkedin" title="Linkedin"><?php echo $trans['sociall']; ?></a></li>
	                        <li><a href="#" data-placement="bottom" data-toggle="tooltip" class="fa fa-rss" title="Feedburner"><?php echo $trans['socialrss']; ?></a></li>
	                    </ul><!-- End Social --> 
					</div><!-- end col-lg-6 col-md-6 col-sm-6-->
				</div><!-- end row-->
			</div><!-- end container-->
		
	
