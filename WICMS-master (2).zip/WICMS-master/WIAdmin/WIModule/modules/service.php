
<body>
<section class="content portfolio_2">			
<div class="s_container">				
<div class="row">					
<div class="col-lg-12 col-md-12 col-sm-12" id="col-pd">

<div class="title"><h1>Services</h1></div>						
<!--begin isotope -->						
<div class="isotope">							
<!--begin portfolio filter -->							
<ul id="filter" class="option-set clearfix">								
<li data-filter="*" class="selected"><a href="#">All</a></li>								
<li data-filter=".responsive"><a href="#">Audio Vanity Books</a></li>								<li data-filter=".mobile"><a href="#">Books</a></li>								
<li data-filter=".branding"><a href="#">Games </a></li>							
</ul>							
<!--end portfolio filter -->														
<!--begin portfolio_list -->   							
<ul id="list" class="portfolio_list clearfix ">								
<!--begin col-lg-6 col-md-6 -->																								<li class="list_item branding col-lg-6 col-md-6 col-sm-6">									<div class="project_container">       										
<div class="img_hover">											
<img src="img/projects/01.jpg" alt="Pandora's Affair Book">											<a class="hover_link" href="portfolio_single.html"><span><i class="fa fa-link"></i></span></a>											<a class="hover_view mfp-image" href="img/projects/01.jpg"><span><i class="fa fa-search"></i></span></a>										</div>																				<div class="project_info">											<h4><a href="http://u-adv.co.uk/BBT/pandora.php">pandora's affair</a></h4>											<a href="http://u-adv.co.uk/BBT/pandora.php">Ebook</a>, <a href="http://u-adv.co.uk/BBT/pandora.php">Paperback</a>, <a href="http://u-adv.co.uk/BBT/pandora.php">Hardcover</a>, <a href="http://u-adv.co.uk/BBT/pandora.php">Signed Paperback</a>											</div>  									</div></li>							</ul> <!--end portfolio_list -->													</div>			
</body>
</html>