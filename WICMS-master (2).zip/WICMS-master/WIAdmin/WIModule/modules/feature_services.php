

<body>
<!--Start Feature Promo Box-->
		<section class="content intro_text_box">
			<div class="w_container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12" data-effect="slide-bottom">
						<div class="intro_box">
							<h1>Welcome to <span>Buddy Boy Technologies</span></h1>
							<p>Buddy Boy Technologies, (BBT) is a whole new level of integration and aptitude for people who want more than just an average run of the mill entertainment experience. Our products will REVOLUTIONIZE the way people view consumer electronics and entertainment, and will show consumers a new and fun way to intertwine learning with new technology and gaming. BBT is bringing new, fun, innovative technology to people who LOVE all kinds of movies, reading all different genres of books, video gaming and other entertainment. </p>
						</div>
					</div>
				
					<div class="col-lg-4 col-md-4 col-sm-4 col-pr-1" data-effect="slide-left" >
						<div class="services">
							<div class="icon">
								<i class="fa fa-laptop"></i>
							</div>
							<div class="serv_detail">
								<h3>Projects</h3>
								<p>The first project of Buddy Boy Technologies is turning Tiffany’s first book, “The Pandora Affair” into a video game. That’s right, an adult romance video game! With interactive programming, you will not only enjoy the book, you will be able to make design, play and conquer your own alternate journey and destination ending. You will experience hands on feelings with remote controlled romance, sex, drama, action, thriller, suspense, murder and humor. </p>
							</div>
						</div>
					</div>
					
					<div class="col-lg-4 col-md-4 col-sm-4" data-effect="slide-bottom">
						<div class="services">
							<div class="icon">
								<i class="fa fa-trophy"></i>
							</div>
							<div class="serv_detail">
								<h3>Creation</h3>
								<p>Along with all Tiffany’s literary creations, there will be many other Independent Authors who will be submitting their work for video game design as well.

Along with the game developments, BBT is also creating standard and custom console boxes with high tech remotes, that allow further interaction with all the games.</p>
							</div>
						</div>
					</div>
					
					<div class="col-lg-4 col-md-4 col-sm-4" data-effect="slide-right">
						<div class="services">
							<div class="icon">
								<i class="fa fa-cogs"></i>
							</div>
							<div class="serv_detail">
								<h3>Educational</h3>
								<p>BBT will be bringing books and educational importance back into technology, video gaming and entertainment.

We will be your new generation, full service technology based entertainment aphrodisiac.

We look forward to bringing you everything you ever wanted in a gaming experience!

Tiffany Toto, Founder and CEO of Buddy Boy Technologies</p>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</section>
		<!--End Feature Services-->
</body>
</html>