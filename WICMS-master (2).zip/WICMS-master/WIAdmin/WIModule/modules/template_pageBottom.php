<!-- **** template_pageBottom.php **** -->

<div id="pageBottom">&copy;2014 Social</div>