

<body>
<section class="promo_box" data-effect="slide-top">
			<div class="container">
				<div class="row">
					<div class="col-lg-10 col-md-10 col-sm-10">
						<h3>Coruscate is awesome responsive template.</h3>
						<p>Nullam ut consectetur dolor. Sed sit amet iaculis nisi. Mauris ridiculus elementum non felis etewe blandit. </p>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2">
						<a href="#fakelink" class="btn btn-line bold">
							<i class="fa fa-shopping-cart"></i>
							Purchase Now
						</a>
					</div>
				</div>
			</div>
		</section>
</body>
</html>