

<body>
<!--Start Footer-->
		<footer class="footer">
			<div class="f_container">
				<div class="row">
					<div class="col-lg-3 col-md-3 col-sm-3"  data-effect="slide-bottom">
						<div class="widget_footer">
							<div class="widget_title">
								<h4>
									<span>About Us</span>
								</h4>
							</div>
							<div class="wfoot_content">
								<p>Donec earum rerum hic tenetur ans sapiente delectus, ut aut reiciendise voluptat maiores alias consequaturs aut perferendis doloribus asperiores.</p>
								<ul class="contact-details-alt">
									<li><i class="fa fa-map-marker"></i> <p><span>Address</span>: 76 Jl. Meo, Singapore</p></li>
									<li><i class="fa fa-user"></i> <p><span>Phone</span>: +0300 330 5486</p></li>
									<li><i class="fa fa-envelope"></i> <p><span>Email</span>: <a href="#">tiffanytoto@bbt.com</a></p></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3"  data-effect="slide-bottom">
						<div class="widget_footer">
							<div class="widget_title">
								<h4>
									<span>Recent Post</span>
								</h4>
							</div>
							
							<div class="wfoot_content">
								<ul class="recent_posts">
					                <li>
				                  		<a href="#" class="post-img">
					                    	<img src="img/blog/recent_1.jpg" alt="">
				                  			<span class="overlay"></span>
				                  		</a>
				                  		<p class="wrap">
					                    	 <a href="#" class="rp_title">Ut enim ad minim veniam</a>
					                    	<small class="rp_date">January 19, 2014</small>
					                  	</p>
					                </li>        
					                <li>
				                  		<a href="#" class="post-img">
						                    <img src="img/blog/recent_2.jpg" alt="">
						                  	<span class="overlay"></span>
					                  	</a>
					                  	<p class="wrap">
					                    	<a href="#" class="rp_title">Lorem ipsum dolor consectetur</a>
					                    	<small class="rp_date">January 19, 2014</small>
					                  	</p>
					                </li>
			                        <li>
			         		         	<a href="#" class="post-img">
					                    	<img src="img/blog/recent_3.jpg" alt="">
					                  		<span class="overlay"></span>
					                  	</a>
				                  		<p class="wrap">
					                    	<a href="#" class="rp_title">Ut enim ad minim et ven veniam, quis nostrud </a>
					                    	<small class="rp_date">January 19, 2014</small>
					                  	</p>
				                	</li> 
				              	</ul>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3"  data-effect="slide-bottom">
						<div class="widget_footer">
							<div class="widget_title">
								<h4>
									<span>Recent Tweets</span>
								</h4>
							</div>
							
							<div class="wfoot_content">
								<div class="tweet_go"></div>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3"  data-effect="slide-bottom">
						<div class="widget_footer">
							<div class="widget_title">
								<h4>
									<span>Flickr Photos</span>
								</h4>
							</div>
							
							<div class="wfoot_content">
								<div class="flickr">
									<ul id="basicuse" class="flickr-feed"></ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!--End Footer-->
</body>
</html>