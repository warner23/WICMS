

<body>
<!--Start Feature Extra-->
		<section class="content feature_rwork ">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12" data-effect="slide-bottom">
						<div class="title">
							<h2>Our Latest Project</h2>
							<p>Nullam ut consectetur dolor. Sed sit amet iaculis nisi. Mauris ridiculus elementum non felis etewe blandit. Vestibulum iaculis dolor porttitors erte.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<!-- Flex-3 -->
					<div class="recent" data-effect="slide-bottom">
						<ul class="carousel3 pb_30">
							<li>
								<div class="col-lg-12 col-md-12 col-sm-12">  
									<div class="project_container">       
										<div class="img_hover">
											<img src="img/projects/01.jpg" alt="">
											<a class="hover_link" href="portfolio_single.html"><span><i class="fa fa-link"></i></span></a>
											<a class="hover_view mfp-image" href="img/projects/01.jpg"><span><i class="fa fa-search"></i></span></a>
										</div>
										
										<div class="project_info">
											<h4> <a href="#">Project Title Here</a> </h4>
											<a href="#">Web Design</a>, <a href="#">Photography</a>
										</div>  
									</div>                           
								</div>
							</li>
							<li>
								<div class="col-lg-12 col-md-12 col-sm-12">  
									<div class="project_container">       
										<div class="img_hover">
											<img src="img/projects/02.jpg" alt="">
											<a class="hover_link" href="portfolio_single.html"><span><i class="fa fa-link"></i></span></a>
											<a class="hover_view mfp-image" href="img/projects/02.jpg"><span><i class="fa fa-search"></i></span></a>
										</div>
										
										<div class="project_info">
											<h4> <a href="#">Project Title Here</a> </h4>
											<a href="#">Web Design</a>, <a href="#">Photography</a>
										</div>  
									</div>                           
								</div>
							</li>
							<li>
								<div class="col-lg-12 col-md-12 col-sm-12">  
									<div class="project_container">       
										<div class="img_hover">
											<img src="img/projects/03.jpg" alt="">
											<a class="hover_link" href="portfolio_single.html"><span><i class="fa fa-link"></i></span></a>
											<a class="hover_view mfp-image" href="img/projects/03.jpg"><span><i class="fa fa-search"></i></span></a>
										</div>
										
										<div class="project_info">
											<h4> <a href="#">Project Title Here</a> </h4>
											<a href="#">Web Design</a>, <a href="#">Photography</a>
										</div>  
									</div>                           
								</div>
							</li>
							<li>
								<div class="col-lg-12 col-md-12 col-sm-12">  
									<div class="project_container">       
										<div class="img_hover">
											<img src="img/projects/04.jpg" alt="">
											<a class="hover_link" href="portfolio_single.html"><span><i class="fa fa-link"></i></span></a>
											<a class="hover_view mfp-image" href="img/projects/04.jpg"><span><i class="fa fa-search"></i></span></a>
										</div>
										
										<div class="project_info">
											<h4> <a href="#">Project Title Here</a> </h4>
											<a href="#">Web Design</a>, <a href="#">Photography</a>
										</div>  
									</div>                           
								</div>
							</li>
							<li>
								<div class="col-lg-12 col-md-12 col-sm-12">  
									<div class="project_container">       
										<div class="img_hover">
											<img src="img/projects/05.jpg" alt="">
											<a class="hover_link" href="portfolio_single.html"><span><i class="fa fa-link"></i></span></a>
											<a class="hover_view mfp-image" href="img/projects/05.jpg"><span><i class="fa fa-search"></i></span></a>
										</div>
										
										<div class="project_info">
											<h4> <a href="#">Project Title Here</a> </h4>
											<a href="#">Web Design</a>, <a href="#">Photography</a>
										</div>  
									</div>                           
								</div>
							</li>
							<li>
								<div class="col-lg-12 col-md-12 col-sm-12">  
									<div class="project_container">       
										<div class="img_hover">
											<img src="img/projects/06.jpg" alt="">
											<a class="hover_link" href="portfolio_single.html"><span><i class="fa fa-link"></i></span></a>
											<a class="hover_view mfp-image" href="img/projects/06.jpg"><span><i class="fa fa-search"></i></span></a>
										</div>
										
										<div class="project_info">
											<h4> <a href="#">Project Title Here</a> </h4>
											<a href="#">Web Design</a>, <a href="#">Photography</a>
										</div>  
									</div>                           
								</div>
							</li>
							
						</ul>
					</div>  
					<!-- Flex-3 End -->   
				</div>   
			</div>
		</section>
		<!--End Feature Extra-->
</body>
</html>