

<body>
<!--Start Feature Client-->
		<section class="content feature_client">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12" data-effect="slide-top">
						<div class="title">
							<h2>Our Client</h2>
							<p>Nullam ut consectetur dolor. Sed sit amet iaculis nisi. Mauris ridiculus elementum non felis etewe blandit. Vestibulum iaculis dolor porttitors erte.</p>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12" data-effect="slide-bottom">
						<!-- Client Slider Carousel -->
				        <div class="owl-carousel carousel2 pb_20 client">
				          	<div class="item"> 
				          		<img src="img/clients/1.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/2.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/3.png" alt="">
				          	</div>
				          	<div class="item"> 
					            <img src="img/clients/4.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/5.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/3.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/1.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/2.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/3.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/4.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/5.png" alt="">
				          	</div>
				          	<div class="item"> 
				            	<img src="img/clients/3.png" alt="">
				          	</div>
			        	</div>  
				        <!-- Client Slider Carousel End -->
                        </div>
				</div>
			</div>
		</section>
		<!--End Feature Client-->
</body>
</html>