
<body>
<header class="header">
			<!-- Static navbar -->
			
				<div class="l_container">
					<div class="row">
						<div class="col-lg-3 col-md-31 col-sm-12">
							<div class="navbar_brand">
                            <div class="logobbt">
								<a href="index.php"><img src="img/BBT_logo3.jpg" alt="BBT" width="257" height="150"></a></div><!-- end logo-->
<div class="head">
 <div class="bbt">
 <a href="http://www.buddyboytechnologies.com" title="Buddy Boy Technologies — Where Creative Intelligence Begins " rel="home"><?php echo $trans['BBT']; ?></a>
 
 </div><!-- end bbt-->
 <div class="slogan"><?php echo $trans['slogan']; ?>
 </div><!-- end slogan-->
 </div><!-- end head-->
 <br class="clearfloat"/>
 </div><!-- navbar-->
						</div><!-- col3-->
                        </div><!-- row-->
                        </div><!-- con-->
                       
                        </header>
</body>
</html>