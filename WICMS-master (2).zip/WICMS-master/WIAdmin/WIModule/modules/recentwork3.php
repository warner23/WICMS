

<body>
<!--Start Feature Extra Parallax -->		
<section class="feature_parallax" id="parallax_3">			
<div class="p_container">				
<div class="row">					
<div class="col-lg-3 col-md-3 col-sm-3" data-effect="slide-bottom">		            	
<div class="counter">		            		
<i class="fa fa-picture-o"></i>		                    
<span class="stat-count">15</span>		                    
<p class="stat-detail">Products being developed</p>		      
</div>		            
</div>					
<div class="col-lg-3 col-md-3 col-sm-3" data-effect="slide-bottom">		            	
<div class="counter">		            		
<i class="fa fa-pencil"></i>		                    
<span class="stat-count">2</span>		                    
<p class="stat-detail">Books</p>		                
</div>		            
</div>					
<div class="col-lg-3 col-md-3 col-sm-3" data-effect="slide-bottom">		            	
<div class="counter">		            		
<i class="fa fa-rocket"></i>		                   
 <span class="stat-count">985</span>		                    
 <p class="stat-detail">Growing Statistics</p>		                
 </div>		            
 </div>					
 <div class="col-lg-3 col-md-3 col-sm-3" data-effect="slide-bottom">		            	
 <div class="counter">		            		
 <i class="fa fa-copy"></i>		                    
 <span class="stat-count">675</span>		                    
 <p class="stat-detail">Ready Document</p>		                
 </div>		           
  </div>				
  </div>			
  </div>		
</section>		<!--End Feature Extra Parallax -->	
</body>
</html>