

<body>
<!--Start Feature RECENT WORK-->
		<section class="content feature_extra" id="parallax_3">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12" data-effect="slide-top">
						<div class="title white">
							<h2>multipurpose Template</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis nostrud exercitation ullamco laboris nisi ut ex ea commodo consequat.</p>
						</div>
					</div>
					
					<div class="col-lg-6 col-md-6 col-sm-6" data-effect="slide-left">
						<div class="feature_slider">
							<ul class="owl-carousel carousel">
								<li class="item"><img src="img/smart.jpg" alt=""></li>
								<li class="item"><img src="img/smart_2.jpg" alt=""></li>
								<li class="item"><img src="img/smart.jpg" alt=""></li>
								<li class="item"><img src="img/smart_2.jpg" alt=""></li>
							</ul>
						</div>
					</div>
					
					<div class="col-lg-6 col-md-6 col-sm-6" data-effect="slide-right">
						<div class="accordion" id="accordion">
                      <div class="accordion-group">
                        <div class="accordion-heading">
            
                          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
                            <i class="fa fa-minus"></i>Our Solutions
                          </a>
                        </div>
                        <div id="collapseOne" class="accordion-body collapse in">
                          <div class="accordion-inner">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                          </div>
                        </div>
                      </div>
                      <div class="accordion-group">
                        <div class="accordion-heading">
                          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
                            <i class="fa fa-plus"></i>Our Missions
                          </a>
                        </div>
                        <div id="collapseTwo" class="accordion-body collapse">
                          <div class="accordion-inner">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                          </div>
                        </div>
                      </div>
                      <div class="accordion-group">
                        <div class="accordion-heading">
                          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
                            <i class="fa fa-plus"></i>Our Visions
                          </a>
                        </div>
                        <div id="collapseThree" class="accordion-body collapse">
                          <div class="accordion-inner">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                          </div>
                        </div>
                      </div>
               		<div class="accordion-group">
                        <div class="accordion-heading">
                          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
                            <i class="fa fa-plus"></i>Our Plan
                          </a>
                        </div>
                        <div id="collapseFour" class="accordion-body collapse">
                          <div class="accordion-inner">
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
                          </div>
                        </div>
                      </div>
                    
	                    	<div class="accordion-group">
		                        <div class="accordion-heading">
		                          <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
		                            <i class="fa fa-plus"></i>Our Feature
		                          </a>
		                        </div>
		                        <div id="collapseFive" class="accordion-body collapse">
		                          <div class="accordion-inner">
		                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.
		                          </div>
		                        </div>
                      		</div>
                    	</div>
					</div>
					
				</div>
			</div>
		</section>
		<!--End Feature RECENT WORK-->
		
		<!--Start Feature Extra-->
</body>
</html>