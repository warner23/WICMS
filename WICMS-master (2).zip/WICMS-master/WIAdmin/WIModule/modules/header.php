
<body>

		
			
				<div class="container">
					<div class="row">
						<div class="col-lg-3 col-md-3 col-sm-12 col-mar-1">
						  <header class="header">
  <div class="hed"></div>
		<!-- Static navbar -->
        </header>
						<div class="col-lg-9 col-md-91 col-sm-12 col-sm-121 col-head-overall ">
							<div id="nav">
		                        <ul id="mainMenu" class="mainMenu default">
		                            
		                                                            
                                    
		                                    <li><a href="services.php"><?php echo $trans['services']; ?></a>
		                                    	<ul class="dropdown">
		                                    		<li><a href="services.php">Vanity Audio Book </a></li>
		                                    		<li><a href="services_2.html">Author Submissions</a></li>
                                                    <li><a href="pandora.php">Books</a></li>
		                                    	</ul>
		                                  
		                                         
		                                    
		                                
		                      
	
   	                           
		                                    		
		                                    	
		                                    <li><a href="about.html"><?php echo $trans['Gaming']; ?></a></li>
		                                
		                            
		                            
		                            <li><a href="forum/index.php">Forum</a>
		                                
		                            </li>
                                    
                                     <li><a href="about.php">About</a>
		                                <ul class="dropdown">
		                                    <li><a href="about.php">About Us</a>
		                                    	<ul class="dropdown">
		                                    		<li><a href="management.php">Management Team </a></li>
		                                    		
		                                    	</ul>
		                                    </li>
                                    <li><a href="contact.php">Contact Us</a></li>
   </ul><li><a href="contact.php">Contact Us</a>
   
    <li><a href="faq.php">FAQ Page</a></li>
		                           
		                            <li><a href="features.php">Features</a>
		                                <ul class="dropdown">
		                                    <li><a href="elements.html">Coming Soon</a></li>
		                                    <li><a href="columns.html">New and Improved</a></li>
		                                    <li><a href="pricing.html">Gallery</a></li>
		                                </ul>
		                            </li>
		                        </ul>
		                    </div><!-- nav -->   
						</div>
					</div>
				</div>
			</div>
           
		</header>
		<!-- End Header -->
