<select name="type" id="type">
    <option value="0" label="select a type ... " selected="selected">Select a type ... </option>
      <option value="EB" label="Ebook">Ebook</option>
    <option value="PB" label="PaperBack">PaperBack</option>
    <option value="SPB" label="Signed PaperBack">Signed PaperBack</option>
    <option value="HC" label="Hardcopy">Hardcopy</option>
</select>