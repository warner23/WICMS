$(document).ready(function(event)
{


});


var wysiwyg = {};

wysiwyg.fontSize = function(){
    
}