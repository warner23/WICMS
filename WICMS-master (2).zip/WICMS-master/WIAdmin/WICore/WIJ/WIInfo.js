/**  **********
*
* namespace
*/

var WIInfo = {};

WIInfo.ShowInfo = function () {
    $("#ShowInfoModal").modal({
        keyboard: false,
        backdrop: "static",
        show: true
    });

};
