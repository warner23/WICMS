<?php 

// Danish
return array(

	// front page

	"site_name"   => "Debate.com",

	"current_topics"  => "Se Aktuelle emner",

	"admin"  => "Admin",

	"info" => "Info",

		//users
	"add_user" => "Tilføj bruger",

	"username" => "brugernavn",

	"email"  => "Email",

	"register_date" => "Registrer Date",

	"confirmed" => "Bekræftet",

	"action" => "Action",

	"no"  => "Nej",

	"yes" => "Ja",

	"edit" => "Rediger",

	"details" => "Detaljer",

	"ban" => "Ban",

	"unban" => "Ophæv udelukkelse",

	"delete" => "Slet",

	"change_role" => "Skift Rolle",

	"loading" => "Indlæser",

	"first_name" => "Fornavn",

	"last_name" => "efternavn",

	"address" => "Adresse",

	"phone" => "telefon",

	"last_login" => "Sidste login",

	"ok" => "Ok",

	"pick_user_role" => "Pick User rolle",

	"select_role" => "Select Rolle",

	"cancel" => "Annuller",

	"add" => "Tilføj",



);
