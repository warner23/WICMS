 <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Dashboard
                        <small>Control panel</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Dashboard</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                    <!-- Small boxes (Stat box) -->
                    <div class="row">
                        <div class="col-lg-3 col-xs-6 col-xl-12">
                            <!-- input box's box -->
                            <div class="modal-body">
            <div class="well">
             <div class="col-lg-12">
           <div class="title"><p>Tasks</p></div>
           <div class="col-lg-12">
           <div class="col-lg-10"></div>
           <div class="col-lg-8">
             
            <?php $site->WITasks() ; ?>
                        </div><!--  col-lg-6 -->
           </div><!--  col-lg-12 -->
           </div><!--  col-lg-12 -->
                     </div>
                     </section>
                      <script type="text/javascript" src="WICore/WIJ/WICore.js"></script>