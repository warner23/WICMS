            <div class="row">
                <div class="col-md-12">
                    <label>Module Caching &nbsp;</label>
                    <div class="btn-group" id="cache">
                        <button class="btn btn-"  data-cache="1" id="icahce_1">Active</button>
                        <button class="btn btn-" data-cache="0" id="icache_0">Inactive</button>
                    </div>
                </div>
                <div class="col-md-12"><br/>
                    <label>Module Preview &nbsp;</label>
                    <div class="btn-group" id="modpreview">
                        <button class="btn btn-"  data-mpv="1" id="modpreview_1">Active</button>
                        <button class="btn btn-"  data-mpv="0" id="modpreview_0">Inactive</button>
                    </div>
                </div>
            </div>