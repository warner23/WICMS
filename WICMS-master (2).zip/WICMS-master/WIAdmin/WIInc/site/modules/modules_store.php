            <div class="row">
                <div class="col-md-12">
                    <div class="alert alert-info" style="font-size: 16px;line-height: 21px;">
                        Extend your WI Modules by adding following premium modules bundle. Each of these bundle packed with some awesome widgets. Check details in product page. 
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="mxaddon" style="max-width: 251px; background: #fff;padding: 10px; border-radius:4px; margin-right: 45px;border: 1px solid #dedede">
                        <a target="blank" href="http://wpeden.com/product/minimax-modules-pack-1/">
                            <img style="height:auto; max-width: 100%;"class="" alt="MiniMax Modules Pack 1" src="http://cdn.wpeden.com/wp-content/uploads/2014/06/minimax-modules-pack-1-250x250.png">
                        </a>
                        <div class="addon-info" style="background:#F4F4F4;margin-top: 20px;padding: 10px;">
                            <a target="blank" style="text-decoration: none;" href="http://wpeden.com/product/minimax-modules-pack-1/">
                                <b>WI Modules Modules Pack 1</b>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="mxaddon" style="max-width: 251px; background: #fff;padding: 10px; border-radius:4px; margin-right: 45px;border: 1px solid #dedede">
                        <a target="blank" href="http://wpeden.com/product/minimax-modules-pack-2/">
                            <img style="height:auto; max-width: 100%;"class="" alt="MiniMax Modules Pack 2" src="http://cdn.wpeden.com/wp-content/uploads/2015/04/minimax-modules-pack-2-250x250.png">
                        </a>
                        <div class="addon-info" style="background:#F4F4F4;margin-top: 20px;padding: 10px;">
                            <a target="blank" style="text-decoration: none;" href="http://wpeden.com/product/minimax-modules-pack-2/">
                                <b>WI Modules Modules Pack 2</b>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                </div>
            </div>