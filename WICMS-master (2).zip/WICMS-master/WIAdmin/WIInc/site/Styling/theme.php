 <form  class="form-horizontal database-form" id="theme">
                      <fieldset>
                        <div id="legend">
                          <legend class="">Theme Settings</legend>
                        </div>

                        

                       <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                         <button>Create New Theme</button>

                       </div>
                       <div id="ViewTheme"></div>
                              <div class="form-group">
                        <!-- Button -->
                        <div class="col-lg-3 col-sm-3 col-md-3">
                           <button id="add_meta_btn" class="btn btn-success" >Add</button> 
                        </div>
                      </div>
                      <div class="results" id="thresults"></div>
                    </fieldset>
                        <br /><br />
                  </form>

