<style type="text/css">
  
    #website_name{
             width: 33%;
    float: left;
  }

</style>


 <form  class="form-horizontal footer" id="footer">
                      <fieldset>
                        <div id="legend">
                          <legend class="">Footer</legend>
                        </div>
                           
                      
                              <div class="form-group">
                        <!-- Button -->
                        <div class="controls col-lg-offset-4 col-lg-8">
                           <button id="footer_btn" class="btn btn-success" >Save</button> 
                        </div>
                      </div>
                      <div class="results" id="fresults"></div>
                    </fieldset>
                        <br /><br />
                  </form>


                      <?php $web->edit_footer();?>

                      