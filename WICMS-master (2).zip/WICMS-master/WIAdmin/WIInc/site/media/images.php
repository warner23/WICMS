<style type="text/css">
	.link{
		cursor: pointer;
	}
</style>
<!-- <div class="col-lg-12 col-sm-12 col-xs-12 col-md-12"> </div>-->

            <div class="row">
            <div class="col-lg-9" id="images">
            	<?php $img->AllPics(); ?>
            </div>

</div>
