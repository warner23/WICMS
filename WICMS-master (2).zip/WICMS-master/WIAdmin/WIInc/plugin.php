 <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Plugin
                        <small>Control panel</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Plugin</li>
                    </ol>
                </section>

                

                <!-- Main content -->
                <section class="content">
                    <!-- Small boxes (Stat box) -->
                    <div class="col-lg-3">
                  
                    </div>
                    <div class="row">
                        <div class="col-lg-3 col-xs-6 col-xl-12">
                            <!-- input box's box -->
                          
                <?php $plug->getPlugins(); ?>

                           
                        </div><!-- ./col -->
                     </div>
                     </section>
                     </aside>
<script type="text/javascript" src="WICore/WIJ/WIPlugin.js"></script>

