<!DOCTYPE html>
<html class="no-js" lang="en">
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php  echo WEBSITE_NAME; ?></title>
	<link rel="stylesheet" type="text/css" href="WIInc/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="WIInc/css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="WIInc/css/mod.css">

	<script src="WIInc/js/jquery.js"></script>
	<script type="text/javascript" src="WIInc/js/bootstrap.min.js"></script>
	
		  <link rel="stylesheet" href="WIInc/css/jquery-ui.css">

<script src="WIInc/js/jquery-1.10.2.js"></script>
  <script src="WIInc/js/jquery_new.js"></script>
  <script src="WIInc/js/jquery-ui.js"></script>

 <link rel="stylesheet" href="WIInc/css/font-awesome.css">



<script type="text/javascript">
            var $_lang = <?php echo WILang::all(); ?>;
        </script> 
</head>
<body>

