<link rel="stylesheet" type="text/css" href="../WITheme/Debate/site/css/frameworks/header.css">
<link rel="stylesheet" type="text/css" href="../WITheme/Debate/site/css/frameworks/footer.css">

<style type="text/css">
  .mediaPic{
        margin-left: 187px;
    margin-top: -289px;
  }
</style>


 <script>
  $( function() {
    $( "#tabs4" ).tabs();
  } );
  </script>


 <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Header
                        <small>Control panel</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Header</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">

                    <!-- Small boxes (Stat box) -->
                    <div class="row">
                        <div class="col-lg-3 col-xs-6 col-xl-12">
                            <!-- input box's box -->
                            <div class="modal-body">


            <div class="well">


                     <div id="tabs4">
  <ul>
    <li><a href="#tabs-1">Header</a></li>
    <li><a href="#tabs-2">Footer</a></li>
    <li><a href="#tabs-3">Favicon</a></li>
  </ul>
  <div id="tabs-1">
<?php include_once 'WIInc/site/header/header.php'; ?>  
  </div>

  <div id="tabs-2">
 <?php include_once 'WIInc/site/header/footer.php'; ?> 
  </div>
  
    <div id="tabs-3">
 <?php include_once 'WIInc/site/header/favicon.php'; ?> 
  </div>
  


</div>

                     </div>
                     </div>
                     </div>
                     </div>

                     </section>
<script type="text/javascript" src="WICore/WIJ/WICore.js"></script>

<script type="text/javascript" src="WICore/WIJ/headerUpload.js"></script>
<script type="text/javascript" src="WICore/WIJ/faviconUpload.js"></script>
<script type="text/javascript" src="WICore/WIJ/WIHeader.js"></script>
<script type="text/javascript" src="WICore/WIJ/WIFooter.js"></script>
  <script type="text/javascript" src="WICore/WIJ/jquery.ajaxfileupload.js"></script>
  <script type="text/javascript" src="WICore/WIJ/WIMedia.js"></script>

