<link rel="stylesheet" type="text/css" href="http://wicms.co.uk/WITheme/River/admin/css/header.css">


<script type="text/javascript" src="WIInc/js/jquery.form.js"></script>

 <aside class="right-side">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        Header
                        <small>Control panel</small>
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Header</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">

                    <!-- Small boxes (Stat box) -->
                    <div class="row">
                        <div class="col-lg-3 col-xs-6 col-xl-12">
                            <!-- input box's box -->
                            <div class="modal-body">


            <div class="well">
                        <ul class="nav nav-tabs">
                <li class="active"><a href="#site" data-toggle="tab">Header</a></li>
                <li><a href="#footer" data-toggle="tab">Footer</a></li>
              </ul>
              <div id="myTabContent" class="tab-content">
                <div class="tab-pane active in" id="site">
                    <?php include_once 'WIInc/site/header/header.php'; ?>  
                </div>

                 <div class="tab-pane in" id="footer">
                 <?php include_once 'WIInc/site/header/footer.php'; ?> 
                </div>
                






                     </div>

                     </div>
                     </div>
                     </div>
                     </div>

                     </section>
<script type="text/javascript" src="WICore/WIJ/WICore.js"></script>


   